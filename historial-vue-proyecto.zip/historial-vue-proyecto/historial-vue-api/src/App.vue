<script>
export default {
  name: "App",
  data() {
    return {
      pages: [
        { label: "Pagina principal", to: "/home" },
        { label: 'Historial de reservas', to: '/bookingHistory' }
      ],
    };
  },
};
</script>

<template>
  <header>

        <div class="flex-column">
          <router-link
              v-for="page in pages"
              :to="page.to"
              custom
              v-slot="{ navigate, href }"
              :key="page.label">
            <pv-button class="btn-booking hover:bg-gray-400"
                       :href="href"
                       @click="navigate">
              {{ page.label }}
            </pv-button>&nbsp;
          </router-link>
        </div>
  </header>

  <RouterView/>
</template>

<style scoped>
.btn-booking {
  font-family: sans-serif;
  background-color: #000;
}
</style>