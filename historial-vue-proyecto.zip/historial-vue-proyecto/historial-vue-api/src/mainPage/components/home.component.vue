<script setup>

</script>

<template>
 <p>Home!</p>
</template>

<style scoped>

</style>