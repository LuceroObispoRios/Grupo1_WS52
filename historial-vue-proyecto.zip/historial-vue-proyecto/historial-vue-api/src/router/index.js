import { createRouter, createWebHistory } from 'vue-router'
import HomeComponent from "@/mainPage/components/home.component.vue";

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/home',
      name: 'home',
      component: HomeComponent
    },
    {
      path: '/',
      redirect: 'home'
    },
    {
      path: "/bookingHistory",
      name: "bookingHistory",
      component: () => import("../bookingHistory/components/booking-list.component.vue"),
    },
  ]
})

export default router
