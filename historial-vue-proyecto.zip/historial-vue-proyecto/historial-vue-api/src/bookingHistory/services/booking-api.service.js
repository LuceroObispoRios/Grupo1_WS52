import http from "@/shared/services/http-common.service";

export class BookingApiService {
    getAll() {
        return http.get('/bookingHistory');
    }
    getById(id) {
        return http.get(`/bookingHistory/${id}`);
    }
    create(data) {
        return http.post('/bookingHistory', data);
    }
}
