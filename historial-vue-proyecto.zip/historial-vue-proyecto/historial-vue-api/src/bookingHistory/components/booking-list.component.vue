<script>
import { BookingApiService } from "../services/booking-api.service";
import BookingCard from "@/bookingHistory/components/booking-card.component.vue";

export default {
  name: "booking-list",
  components: { BookingCard},
  data() {
    return {
      bookingList: [],
      errors: [],
      bookingApiService: new BookingApiService()
    };
  },
  created() {
    this.getAllBookingHistory();
  },
  methods: {
    getAllBookingHistory(){
      this.bookingApiService.getAll()
          .then((response) => {
            this.bookingList = response.data;
            this.bookingList.reverse();
            console.log(this.bookingList);
          })
          .catch((error) => {
            this.errors.push(error);
          });
    }
  }
};
</script>

<template>
  <div>
    <router-link to="/home" custom v-slot="{ navigate, href }" key="Home">
      <div><pv-button class="pi pi-arrow-left text-black-alpha-90 mt-3 hover:bg-yellow-200"
                      rounded outlined aria-label="Favorite" :href="href" @click="navigate" /></div>
    </router-link>
  </div>
  <div><h1 class="title flex justify-content-center">Historial de Reservas</h1></div>
  <div v-for="bookingHistory in bookingList">
    <booking-card :bookingHistory="bookingHistory"></booking-card>
  </div>
</template>

<style scoped>
.title {
  color: #FDAE39;
  font-family: sans-serif;
}
</style>
  