import { createApp } from 'vue';
import App from './App.vue';
import router from './router';

const app = createApp(App);

// Variable global para el contador de boletas
let contadorBoletas = 1;

// Proporciona acceso al contador global en toda la aplicación
app.config.globalProperties.$contadorBoletas = contadorBoletas;

app.use(router)

app.mount('#app')