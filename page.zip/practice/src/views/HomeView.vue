<script setup>
//import TheWelcome from '../components/FormularioPage.vue'
</script>

<template>
  <main>
    <TheWelcome />
  </main>
</template>
