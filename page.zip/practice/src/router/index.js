import { createRouter, createWebHistory } from 'vue-router'
import MembresiaPage from '@/components/MembresiaPage.vue';
import FormularioPage from '@/components/FormularioPage.vue';
import BoletaModal from "@/components/BoletaModal.vue";

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    { path: '/', component: MembresiaPage },
    { path: '/formulario', component: FormularioPage },
    { path: '/boleta', component: BoletaModal,
      props: (route) => ({
        nombre: route.query.nombre,
        apellido: route.query.apellido,
        ruc: route.query.ruc,
        direccion: route.query.direccion,
        tipoMembresia: route.query.tipoMembresia,
        tipoTarjeta: route.query.tipoTarjeta,
        numeroBoleta: route.query.numeroBoleta,
      })
    }
  ]
})

export default router;